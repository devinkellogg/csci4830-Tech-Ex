/*
 * @(#) MyInject.java
 *
 */
package pkg4;

public @interface MyInject {

}
