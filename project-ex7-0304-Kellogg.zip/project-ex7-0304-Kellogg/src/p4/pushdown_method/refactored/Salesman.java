package p4.pushdown_method.refactored;

public class Salesman extends Employee {

   private String saleQuota;

   String getSaleQuota() {
    	return this.saleQuota;
    }
}
