package q1.extract_method.refactored;

import java.util.List;

public class A {
   Node m1(List<Node> nodes, String p) {
	   m3(nodes, p);
	   return null;
   }

   Edge m2(List<Edge> edgeList, String p) {
	   m3(edgeList, p);
	   return null;
   }

   <T extends Graph> void m3(List<T> objs, String p) {
	      for (T obj : objs) {
	         if (obj.contains(p))
	            System.out.println(obj);
	      }
   }
}

class Graph {
	String name;
	
	public boolean contains(String p) {
		return name.contains(p);
	}
}

class Node extends Graph {

}

class Edge extends Graph {

}